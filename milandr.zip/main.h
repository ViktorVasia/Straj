#include <1986VE9x.h>           // Подключение заголовка микроконтроллера
#define   F_CPU 8000000         // Указание тактовой частоты МК
#define STANDS  12              // кол-во стэндов
#include  "milkites_delay.h"    // Подключение библиотеки задержек
#include  "milkites_display.h"  // Подключение библиотеки дисплея
#include  "UART.h"              // UART
#include  "ADC.h"               // Поключение функционала АЦП
#include  "Straj.h"             // Подключения функционала мультиплексора
#include  "Timer.h"             // Подлючения функционала таймеров
#include  "Init.h"              // Инициализация МК

#define LCD_led_en  MDR_PORTE->RXTX |=  (1<<2)  // вкл. подсветки 
#define LCD_led_dis  MDR_PORTE->RXTX &= ~(1<<2) // выкл. подсветки

void Indication(); // ф-я вывода состояния стэндов
void inquiry_stand(uint8_t data);// обработка полученного запроса по UART
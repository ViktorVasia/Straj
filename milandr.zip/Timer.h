#define TIM1_INTERRUPT 5000        // Период опроса АЦП (мс.)
#define GET_CURRENT(x) ((int32_t) ((((float)x*0.0008) / (0.1*200)) * 1000))
#define DELAY_UART 5               // задержка между отправкой байта в UART

volatile uint32_t Count_current=0;  // счетчик снятия показаний
volatile uint32_t Current[STANDS];  // токопотребление стендов
volatile uint32_t Current_general;  // значение общего тока

//------------------ Timer 1 ----------------------------------------------
void Timer1_init(void) 
{ // настройка Т1 на генерирование прерывания каждую секунду   
  MDR_RST_CLK->TIM_CLOCK |= (1<< 24); // вкл. тактирование Таймера 1 
  
  // режим счета – вверх,начальное значение – число из регистра CNT 
  MDR_TIMER1->CNTRL = 0x00000000;     
  MDR_TIMER1->PSG = 7999;  // предделитель частоты  
  MDR_TIMER1->ARR = TIM1_INTERRUPT-1;   // основание счета = CNT + 1 = TIM1_INTERRUPT
  MDR_TIMER1->CNT = 0;     // начальное значение счетчика 
  MDR_TIMER1->IE  = 2;     // разрешение генерир. прерывание при CNT=ARR 
}

void Timer1_IRQHandler(void)
{
  if(Count_current==STANDS)           // если все сенды опрошены
  {                                   // снять общее напряжение
    Count_current=0;                  // обнуление счетчика

    MCU_ADC_set_ch(5);                // уст. канала АЦП для изм. общ. напряжения
    Current_general=GET_CURRENT(MCU_ADC_read());// чтение общ. тока

    uart_send_byte(Current_general);  // отправка 1 байта
    uart_send_byte(Current_general>>8);// отправка 2 байта
    uart_send_byte('g');              // откуда сняты показаний
  }
  else
  {
      MCU_ADC_set_ch(3);                      // уст. канала АЦП для стендов
      MX_set_channel(Count_current+1);                    // уст. канала мультиплексора
      Current[Count_current]=GET_CURRENT(MCU_ADC_read()); // чтение значений
      
/*
      if (Count_current==1)
      {
        uart_send_byte(Current[Count_current]);// отправка 1 байта
        uart_send_byte(Current[Count_current]>>8);// отправка 2 байта
        uart_send_byte(Count_current);          // откуда сняты показаний
      }
    else{
    uart_send_byte(0);// отправка 1 байта
    uart_send_byte(0);// отправка 2 байта
    uart_send_byte(Count_current);          // откуда сняты показаний
*/
    uart_send_byte(Current[Count_current]);// отправка 1 байта
    uart_send_byte(Current[Count_current]>>8);// отправка 2 байта
    uart_send_byte(Count_current);          // откуда сняты показаний
   
    Count_current++;                  // инкримент
  }

  /*
  MX_set_channel(Count_current+1);    // уст. канала на стенд
  MCU_ADC_set_ch(4);                  // уст. канала АЦП для изм. ШУНТа
  
  uint32_t data = 600;                // какое-то число для UART
  if (data<256)                       // если число меньше 2 байт
    uart_send_byte(data);             // отправить один байт
  else                                // если число больше одного байта
  {
    uart_send_byte(data);             // оправка первого байта
    delay_ms(5);                      // небольшая задержка
    uart_send_byte(data>>8);          // отправляем второй байт пример 0b1011001100>>8 = 0b00000010
  }
  */
  
  MDR_TIMER1->CNT = 0;                // сброс счетчика таймера 
  MDR_TIMER1->STATUS = 0;             // сброс статуса прерывания 
  NVIC_ClearPendingIRQ(Timer1_IRQn);  // сброс статуса прерывания 
}

 
void Timer1_start(void) 
{         
  MDR_TIMER1->CNTRL = 1; // команда запуска Таймера 1   
}
//--------------------------------------------------------------------------
 
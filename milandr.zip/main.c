#include "main.h"   // подключение заголовка микроконтроллера
//#define ESP
#define Milandr

uint8_t stand[STANDS];
uint8_t In_data;  // входные данные

#define DELAY_ADC 50  // задержка между измерением показаний с АЦП

// Основная функция
int main(void)
{
  #ifdef Milandr
  Init_per();
  while (true) 
  {
    Indication();
  }
  #endif
  
  #ifdef ESP
  while(true){}
  #endif
}

/**
  * @brief      Прерывание UART1
  * @detailed   Прерывание возникает при поступлении 1 байта
  * @param      Функция не принимает параметры
  * @return     Функция не возвращает параметры
  *  */
void UART1_IRQHandler(void) 
{
  while(MDR_UART1->FR & 1<<6)
  {
    In_data = MDR_UART1->DR;          // чтение данных

    // Обработка команды.           По UART были замечены помехи с этой целью были добавлены условия
    if (((In_data/10)<=STANDS)&&((In_data/10)>0))
    {
      if (In_data%10==1)
      {
        inquiry_stand(In_data);
        stand[(In_data/10)-1]=1;
      }
      else if (In_data%10==0)
      {
        inquiry_stand(In_data);
        stand[(In_data/10)-1]=0;
      }
    }

    //stand[(In_data/10)-1]=In_data%10; // обработка команды
  }
  MDR_UART1->ICR  = 1 << 4;           // сброс прерывания
}

void Indication() // ф-я вывода состояния стэндов
{
  uint8_t page=0;
  for (uint8_t i=0;i<STANDS;i++)
  {
    if (page<8)
    {
      LCD_page_set(page++);
      LCD_column_set(0);
      LCD_print_text("Stand[");
      LCD_print_num(i+1);
      LCD_print_text("]=");
      if (stand[i]==1)
        LCD_print_text("ON  ");
      else 
        LCD_print_text("OFF");
    }
    else
    {
      LCD_page_set(page++-8);
      LCD_column_set(80);
      LCD_print_text("[");
      LCD_print_num(i+1);
      LCD_print_text("]=");
      if (stand[i]==1)
        LCD_print_text("ON  ");
      else
        LCD_print_text("OFF");
    }
  }
}

/**
  * @brief      Обработка полученного запроса по UART
  * @detailed   Ф-я выполняет полученную команду по UART
  * @param      @data - полученные запрос
  * @return     Функция не возвращает параметры
  *  */
void inquiry_stand(uint8_t data)
{
  if (((In_data/10)<=STANDS)&&((In_data/10)>0)) // если требуется вкл./выкл. стенд
  {
    switch(In_data/10)
    {
      case 1:                       // Стенд 1
        if (In_data%10)
          S1_EN;
        else 
          S1_DIS;
        break;

      case 2:                       // Стенд 2
        if (In_data%10)
          S2_EN;
        else 
          S2_DIS;
        break;

      case 3:                       // Стенд 3
        if (In_data%10)
          S3_EN;
        else 
          S3_DIS;
        break;

      case 4:                       // Стенд 4
        if (In_data%10)
          S4_EN;
        else 
          S4_DIS;
        break;

      case 5:                       // Стенд 5
        if (In_data%10)
          S5_EN;
        else 
          S5_DIS;
        break;

      case 6:                       // Стенд 6
        if (In_data%10)
          S6_EN;
        else 
          S6_DIS;
        break;

      case 7:                       // Стенд 7
        if (In_data%10)
          S7_EN;
        else 
          S7_DIS;
        break;

      case 8:                       // Стенд 8
        if (In_data%10)
          S8_EN;
        else 
          S8_DIS;
        break;

      case 9:                       // Стенд 9
        if (In_data%10)
          S9_EN;
        else 
          S9_DIS;
        break;

      case 10:                      // Стенд 10
        if (In_data%10)
          S10_EN;
        else 
          S10_DIS;
        break;

      case 11:                      // Стенд 11
        if (In_data%10)
          S11_EN;
        else 
          S11_DIS;
        break;

      case 12:                      // Стенд 12
        if (In_data%10)
          S12_EN;
        else 
          S12_DIS;
        break;
    }
  }
}